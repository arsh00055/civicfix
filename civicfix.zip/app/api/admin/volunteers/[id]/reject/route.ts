import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/db'
import { ObjectId } from 'mongodb'
import { getServerSession } from 'next-auth'

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const { id } = params
    const body = await req.json()
    const { reason } = body

    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ message: 'Invalid volunteer ID' }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    const volunteer = await db.collection('users').findOne({
      _id: new ObjectId(id),
      role: 'volunteer',
    })

    if (!volunteer) {
      return NextResponse.json({ message: 'Volunteer not found' }, { status: 404 })
    }

    // Reject karo reason ke saath
    const result = await db.collection('users').updateOne(
      { _id: new ObjectId(id) },
      {
        $set: {
          approvalStatus: 'rejected',
          rejectionReason: reason || 'No reason provided',
          rejectedAt: new Date(),
          updatedAt: new Date(),
        },
      }
    )

    if (result.modifiedCount === 0) {
      return NextResponse.json({ message: 'Failed to reject volunteer' }, { status: 500 })
    }

    // TODO: Notification bhejo volunteer ko
    // await sendNotification(volunteer.email, 'rejected', reason)

    return NextResponse.json({
      success: true,
      message: `${volunteer.name} di application reject kar diti gayi.`,
    })
  } catch (error: any) {
    console.error('Reject volunteer error:', error)
    return NextResponse.json(
      { success: false, message: 'Server error', error: error.message },
      { status: 500 }
    )
  }
}