import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/db'
import { ObjectId } from 'mongodb'
import { getServerSession } from 'next-auth'

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession()
    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const { id } = params

    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ message: 'Invalid volunteer ID' }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    // Pehle check karo volunteer exist karta hai ya nahi
    const volunteer = await db.collection('users').findOne({
      _id: new ObjectId(id),
      role: 'volunteer',
    })

    if (!volunteer) {
      return NextResponse.json({ message: 'Volunteer not found' }, { status: 404 })
    }

    if (volunteer.approvalStatus === 'approved') {
      return NextResponse.json({ message: 'Volunteer already approved' }, { status: 400 })
    }

    // Approve karo
    const result = await db.collection('users').updateOne(
      { _id: new ObjectId(id) },
      {
        $set: {
          approvalStatus: 'approved',
          approvedAt: new Date(),
          status: 'available', // Volunteer ab available ho gaya
          updatedAt: new Date(),
        },
        $unset: {
          rejectionReason: '', // Agar pehle reject tha to reason hata do
        },
      }
    )

    if (result.modifiedCount === 0) {
      return NextResponse.json({ message: 'Failed to approve volunteer' }, { status: 500 })
    }

    // TODO: Notification bhejo volunteer ko (lib/helpers/notification.helper.ts use karo)
    // await sendNotification(volunteer.email, 'approved')

    return NextResponse.json({
      success: true,
      message: `${volunteer.name} nu successfully approve kar dita gaya!`,
    })
  } catch (error: any) {
    console.error('Approve volunteer error:', error)
    return NextResponse.json(
      { success: false, message: 'Server error', error: error.message },
      { status: 500 }
    )
  }
}