import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/db'
import { getServerSession } from 'next-auth'

export async function GET(req: NextRequest) {
  try {
    // Auth check - sirf admin access kar sakta
    const session = await getServerSession()
    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const { db } = await connectToDatabase()

    // Pending volunteers fetch karo users collection se
    const pendingVolunteers = await db
      .collection('users')
      .find({
        role: 'volunteer',
        approvalStatus: 'pending',
      })
      .project({
        _id: 1,
        name: 1,
        email: 1,
        skills: 1,
        experienceLevel: 1,
        phone: 1,
        bio: 1,
        createdAt: 1,
        avatar: 1,
        location: 1,
      })
      .sort({ createdAt: -1 })
      .toArray()

    return NextResponse.json({
      success: true,
      data: pendingVolunteers,
      count: pendingVolunteers.length,
    })
  } catch (error: any) {
    console.error('Pending volunteers fetch error:', error)
    return NextResponse.json(
      { success: false, message: 'Server error', error: error.message },
      { status: 500 }
    )
  }
}