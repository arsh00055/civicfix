describe('Login Flow', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000/login')
  })

  it('renders login page with role selector', () => {
    cy.contains('Login').should('exist')
  })

  it('citizen can select role and see login form', () => {
    cy.contains('Citizen').click()
    cy.get('input[type="email"]').should('exist')
    cy.get('input[type="password"]').should('exist')
  })

  it('shows error on invalid credentials', () => {
    cy.contains('Citizen').click()
    cy.get('input[type="email"]').type('wrong@gmail.com')
    cy.get('input[type="password"]').type('wrongpassword')
    cy.get('button[type="submit"]').click()
    cy.contains('Invalid').should('exist')
  })

  it('successful citizen login redirects to dashboard', () => {
    cy.contains('Citizen').click()
    cy.get('input[type="email"]').type('adeepkaur727@gmail.com')
    cy.get('input[type="password"]').type('arshdeep')
    cy.get('button[type="submit"]').click()
    cy.url().should('include', '/citizen')
  })
})