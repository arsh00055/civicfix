// 'use client';

// import React, { useState, useEffect } from 'react';
// import MainLayout from '@/components/layout/MainLayout';
// import ProfileHeader from './components/ProfileHeader';
// import ProfileSidebar from './components/ProfileSidebar';
// import Loading from '@/app/loading';
// import Error from '@/app/error';
// import AchievementsSection from './components/AchievementsSection';
// import { useAuth } from '@/features/auth/hooks/useAuth';
// import apiClient from '@/lib/services/api/client';
// import VerificationModal from './components/VerificationModal';

// interface UserStats {
//   communityScore: number;
//   issuesReported: number;
//   issuesResolved: number;
//   achievements: number;
// }

// const ProfilePage: React.FC = () => {
//   const { user: currentUser } = useAuth();
//   const [user, setUser] = useState<any>(null);
//   const [stats, setStats] = useState<UserStats>({
//     communityScore: 0,
//     issuesReported: 0,
//     issuesResolved: 0,
//     achievements: 0,
//   });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [emailVerified, setEmailVerified] = useState(false);
//   const [showEmailModal, setShowEmailModal] = useState(false);

//   useEffect(() => {
//     if (currentUser) fetchUserData();
//   }, [currentUser]);

//   const fetchUserData = async () => {
//     try {
//       setLoading(true);
//       setError(null);

//       if (!currentUser?.id) {
//         setError('User not authenticated');
//         setLoading(false);
//         return;
//       }

//       const userResponse = await apiClient.get('/users/profile');
//       const userData = userResponse.data || userResponse;
//       const fetchedUser = userData.user || userData;
//       setUser(fetchedUser);

//       // ✅ Database ਤੋਂ email verified status ਲਓ
//       setEmailVerified(fetchedUser.isEmailVerified || false);

//       try {
//         const res = await apiClient.get('/users/stats')
//         const data = res.data || res
      
//         if (currentUser?.role === 'admin') {
//           // Admin ਲਈ platform stats
//           setStats({
//             issuesReported: data.totalIssues || 0,
//             issuesResolved: data.resolvedIssues || 0,
//             achievements: data.totalUsers || 0,
//             communityScore: data.points || 0,
//           })
//         } else if (currentUser?.role === 'volunteer') {
//           setStats({
//             issuesReported: data.tasksCompleted || 0,
//             issuesResolved: data.totalClaimed || 0,
//             achievements: data.totalRatings || 0,
//             communityScore: data.points || 0,
//           })
//         } else {
//           // Citizen
//           setStats({
//             issuesReported: data.totalReports || 0,
//             issuesResolved: data.resolvedReports || 0,
//             achievements: data.unlockedAchievements || 0,
//             communityScore: data.points || 0,
//           })
//         }
//       } catch {
//         console.warn('Could not fetch stats')
//       }

//     } catch (err) {
//       console.error('Failed to fetch user data:', err);
//       setError('Failed to load profile data');
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) return <Loading />;
//   if (error || !user) return <Error error={error as unknown as Error & { digest?: string }} reset={() => {}} />;

//   return (
//     <MainLayout role={user?.role}>
//       <div className="container mx-auto px-4 py-8">
//         <div className="max-w-6xl mx-auto">
//           <ProfileHeader
//             user={user}
//             stats={{
//               issuesReported: stats.issuesReported,
//               issuesResolved: stats.issuesResolved,
//               communityScore: stats.communityScore ?? 0,
//               achievements: stats.achievements,
//             }}
//           />

//           <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mt-6">
//             {/* Sidebar */}
//             <div className="lg:col-span-1">
//             <ProfileSidebar user={{...user, isEmailVerified: emailVerified}} />
//             </div>

//             {/* Main Content */}
//             <div className="lg:col-span-3 space-y-6">
//               <AchievementsSection />

//               {/* ✅ Email Verification Banner - sirf unverified ਤੇ show ਕਰੋ */}
//               {!emailVerified && (
//                 <div className="rounded-xl border border-yellow-200 bg-yellow-50 p-5 flex items-center justify-between gap-4">
//                   <div className="flex items-center gap-4">
//                     <div className="text-3xl p-3 rounded-full bg-yellow-100">✉️</div>
//                     <div>
//                       <p className="font-semibold text-base text-yellow-800">
//                         Verify your Email
//                       </p>
//                       <p className="text-sm mt-0.5 text-yellow-700">
//                         {user.email} — Please verify to access all features
//                       </p>
//                     </div>
//                   </div>
//                   <button
//                     onClick={() => setShowEmailModal(true)}
//                     className="shrink-0 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors"
//                   >
//                     Verify Now →
//                   </button>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Email Verification Modal */}
//       {showEmailModal && (
//         <VerificationModal
//           type="email"
//           onClose={() => setShowEmailModal(false)}
//           onSuccess={(type) => {
//             if (type === 'email') {
//               setEmailVerified(true); // ✅ Banner ਤੁਰੰਤ ਹੱਟ ਜਾਵੇਗਾ
//             }
//             setShowEmailModal(false);
//           }}
//           userEmail={user.email}
//           userPhone={user.phone}
//           phoneVerified={user.verification?.phone || false}
//         />
//       )}
//     </MainLayout>
//   );
// };

// export default ProfilePage;



'use client';

import React, { useState, useEffect } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import ProfileHeader from './components/ProfileHeader';
import ProfileSidebar from './components/ProfileSidebar';
import Loading from '@/app/loading';
import Error from '@/app/error';
import AchievementsSection from './components/AchievementsSection';
import { useAuth } from '@/features/auth/hooks/useAuth';
import apiClient from '@/lib/services/api/client';
import VerificationModal from './components/VerificationModal';

interface UserStats {
  communityScore: number;
  issuesReported: number;
  issuesResolved: number;
  achievements: number;
}

const ProfilePage: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<UserStats>({
    communityScore: 0,
    issuesReported: 0,
    issuesResolved: 0,
    achievements: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [emailVerified, setEmailVerified] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);

  useEffect(() => {
    if (currentUser) fetchUserData();
  }, [currentUser]);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      setError(null);

      if (!currentUser?.id) {
        setError('User not authenticated');
        setLoading(false);
        return;
      }

      const userResponse = await apiClient.get('/users/profile');
      const userData = userResponse.data || userResponse;
      const fetchedUser = userData.user || userData;
      setUser(fetchedUser);

      // ✅ ਦੋਵੇਂ fields check ਕਰੋ
      setEmailVerified(
        fetchedUser.verification?.email || fetchedUser.isEmailVerified || false
      );

      try {
        const res = await apiClient.get('/users/stats');
        const data = res.data || res;

        if (currentUser?.role === 'admin') {
          setStats({
            issuesReported: data.totalIssues || 0,
            issuesResolved: data.resolvedIssues || 0,
            achievements: data.totalUsers || 0,
            communityScore: data.points || 0,
          });
        } else if (currentUser?.role === 'volunteer') {
          setStats({
            issuesReported: data.tasksCompleted || 0,
            issuesResolved: data.totalClaimed || 0,
            achievements: data.totalRatings || 0,
            communityScore: data.points || 0,
          });
        } else {
          setStats({
            issuesReported: data.totalReports || 0,
            issuesResolved: data.resolvedReports || 0,
            achievements: data.unlockedAchievements || 0,
            communityScore: data.points || 0,
          });
        }
      } catch {
        console.warn('Could not fetch stats');
      }

    } catch (err) {
      console.error('Failed to fetch user data:', err);
      setError('Failed to load profile data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <Loading />;
  if (error || !user) return <Error error={error as unknown as Error & { digest?: string }} reset={() => {}} />;

  const isAdmin = currentUser?.role === 'admin';

  // ✅ emailVerified state ਨਾਲ user object ਹਰ ਵਾਰ updated ਰਹੇਗਾ
  const updatedUser = {
    ...user,
    verification: {
      ...user?.verification,
      email: emailVerified,
    },
  };

  return (
    <MainLayout role={user?.role}>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">

          {/* ✅ updatedUser pass ਕਰੋ */}
          <ProfileHeader
            user={updatedUser}
            stats={{
              issuesReported: stats.issuesReported,
              issuesResolved: stats.issuesResolved,
              communityScore: stats.communityScore ?? 0,
              achievements: stats.achievements,
            }}
          />

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mt-6">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <ProfileSidebar user={updatedUser} />
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-6">

              {/* Admin ਲਈ Achievements ਨਹੀਂ */}
              {!isAdmin && <AchievementsSection />}

              {/* Admin Stats Cards */}
              {isAdmin && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-2xl">📋</div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">{stats.issuesReported}</div>
                      <div className="text-sm text-gray-500">Total Issues</div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-2xl">✅</div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">{stats.issuesResolved}</div>
                      <div className="text-sm text-gray-500">Resolved Issues</div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center text-2xl">👥</div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">{stats.achievements}</div>
                      <div className="text-sm text-gray-500">Total Citizens</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Email Verification Banner - Admin ਲਈ ਨਹੀਂ */}
              {!isAdmin && !emailVerified && (
                <div className="rounded-xl border border-yellow-200 bg-yellow-50 p-5 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="text-3xl p-3 rounded-full bg-yellow-100">✉️</div>
                    <div>
                      <p className="font-semibold text-base text-yellow-800">
                        Verify your Email
                      </p>
                      <p className="text-sm mt-0.5 text-yellow-700">
                        {user.email} — Please verify to access all features
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowEmailModal(true)}
                    className="shrink-0 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors"
                  >
                    Verify Now →
                  </button>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>

      {/* Email Verification Modal */}
      {showEmailModal && (
        <VerificationModal
          type="email"
          onClose={() => setShowEmailModal(false)}
          onSuccess={(type) => {
            if (type === 'email') {
              // ✅ ਤੁਰੰਤ update ਹੋਵੇਗਾ - refresh ਦੀ ਲੋੜ ਨਹੀਂ
              setEmailVerified(true);
            }
            setShowEmailModal(false);
          }}
          userEmail={user.email}
          userPhone={user.phone}
          phoneVerified={user.verification?.phone || false}
        />
      )}
    </MainLayout>
  );
};

export default ProfilePage;