'use client';

import React, { useState, useEffect } from 'react';
import PrimaryButton from '@/components/UI/buttons/PrimaryButton';
import SecondaryButton from '@/components/UI/buttons/SecondaryButton';
import { usersAPI } from '@/lib/services/api/endpoints';
import { useAuth } from '@/features/auth/hooks/useAuth';

function SkillsSection() {
  const { user } = useAuth();
  const [skills, setSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user && Array.isArray((user as any).skills)) {
      setSkills((user as any).skills);
    } else {
      setSkills([]);
    }
  }, [user]);


  const commonSkills = [
    'Carpentry', 'Electrical', 'Plumbing', 'Gardening', 'Painting',
    'First Aid', 'Teaching', 'Cooking', 'Cleaning', 'Organization',
    'Communication', 'Leadership', 'Technical Support', 'Event Planning'
  ];

  const addSkill = (skill: string) => {
    const trimmedSkill = skill.trim();
    if (trimmedSkill && !skills.includes(trimmedSkill)) {
      setSkills(prev => [...prev, trimmedSkill]);
    }
    setNewSkill('');
  };

  const removeSkill = (skillToRemove: string) => {
    setSkills(prev => prev.filter(skill => skill !== skillToRemove));
  };

  const saveSkills = async () => {
    if (!user) return;

    try {
      setSaving(true);
      await usersAPI.updateProfile({ ...user, skills });
      setIsEditing(false);
      // Optionally show success message
    } catch (err) {
      console.error('Failed to save skills:', err);
      // Optionally show error message
    } finally {
      setSaving(false);
    }
  };

  const cancelEditing = () => {
    setIsEditing(false);
    if (user && Array.isArray((user as any).skills)) {
      setSkills((user as any).skills);
    }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Skills & Expertise</h2>
          <p className="text-gray-600 mt-1">
            Showcase your skills to help match you with relevant community issues
          </p>
        </div>
        
        {!isEditing ? (
          <SecondaryButton
            onClick={() => setIsEditing(true)}
          >
            Edit Skills
          </SecondaryButton>
        ) : (
          <div className="flex space-x-2">
            <SecondaryButton
              onClick={cancelEditing}
              disabled={saving}
            >
              Cancel
            </SecondaryButton>
            <PrimaryButton
              onClick={saveSkills}
              disabled={saving}
              isLoading={saving}
            >
              Save
            </PrimaryButton>
          </div>
        )}
      </div>

      {isEditing ? (
        <div className="space-y-4">
          {/* Add Skill Input */}
          <div className="flex space-x-3">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="Add a skill..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newSkill.trim()) {
                  addSkill(newSkill);
                }
              }}
            />
            <PrimaryButton
              onClick={() => addSkill(newSkill)}
              disabled={!newSkill.trim()}
            >
              Add
            </PrimaryButton>
          </div>

          {/* Common Skills Suggestions */}
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Common Skills</h4>
            <div className="flex flex-wrap gap-2">
              {commonSkills.map(skill => (
                <button
                  key={skill}
                  onClick={() => addSkill(skill)}
                  disabled={skills.includes(skill)}
                  className={`px-3 py-1 rounded-full cursor-pointer text-sm transition-colors ${
                    skills.includes(skill)
                      ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                      : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                  }`}
                >
                  + {skill}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {/* Skills Display */}
      <div className="flex flex-wrap gap-2">
        {skills.map(skill => (
          <div
            key={skill}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
          >
            <span>{skill}</span>
            {isEditing && (
              <button
                onClick={() => removeSkill(skill)}
                className="w-4 h-4 rounded-full cursor-pointer bg-blue-200 hover:bg-blue-300 text-blue-800 flex items-center justify-center text-xs"
                disabled={saving}
              >
                ×
              </button>
            )}
          </div>
        ))}

        {skills.length === 0 && (
          <p className="text-gray-500 text-center py-4">
            No skills added yet. {!isEditing && 'Click "Edit Skills" to add your skills.'}
          </p>
        )}
      </div>

      {/* Skill Levels (Optional - can be implemented later) */}
      {skills.length > 0 && isEditing && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Skill Proficiency (Optional)</h4>
          <div className="space-y-3">
            {skills.map(skill => (
              <div key={skill} className="flex items-center justify-between">
                <span className="text-sm text-gray-700">{skill}</span>
                <select 
                  className="text-sm border border-gray-300 cursor-pointer rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  defaultValue="intermediate"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                  <option value="expert">Expert</option>
                </select>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
};

export default SkillsSection;