// 'use client'

// import React, { useState, useEffect } from 'react'
// import apiClient from '@/lib/services/api/client'
// import ReportsHeader from './components/ReportsHeader'
// import ReportGenerator from './components/ReportGenerator'
// import ReportsList from './components/ReportsList'

// type ReportType = 'issues' | 'users' | 'performance' | 'financial' | 'system'
// type ReportFormat = 'pdf' | 'csv' | 'excel'

// interface Report {
//   id: string
//   title: string
//   description: string
//   type: ReportType
//   format: ReportFormat
//   generatedAt: string
//   period: string
//   downloadUrl?: string
//   status?: 'generating' | 'completed' | 'failed'
//   fileSize?: string
// }

// export default function ReportsPage() {
//   const [reports, setReports] = useState<Report[]>([])
//   const [loading, setLoading] = useState(true)
//   const [generating, setGenerating] = useState<string | null>(null)
//   const [error, setError] = useState<string | null>(null)

//   useEffect(() => {
//     fetchReports()
//   }, [])

//   const fetchReports = async () => {
//     try {
//       setLoading(true)
//       setError(null)
      
//       const response = await apiClient.get('/admin/reports')
//       setReports(response.data.reports || response.data.data || []);
//     } catch (err: any) {
//       console.error('Failed to fetch reports:', err)
//       setError(err.message || 'Failed to load reports. Please try again.')
//     } finally {
//       setLoading(false)
//     }
//   }

//   // const generateReport = async (type: ReportType, format: ReportFormat) => {
//   //   const reportId = `${type}-${format}-${Date.now()}`
//   //   setGenerating(reportId)
//   //   setError(null)

//   //   try {
//   //     const response = await apiClient.get('/admin/analytics/export', {
//   //       params: { format, type }
//   //     })

//   //     const newReport: Report = {
//   //       id: reportId,
//   //       title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
//   //       description: getReportDescription(type),
//   //       type,
//   //       format,
//   //       generatedAt: new Date().toISOString(),
//   //       period: getReportPeriod(),
//   //       downloadUrl: response.data.downloadUrl,
//   //       status: 'completed',
//   //       fileSize: response.data.fileSize
//   //     }

//   //     setReports(prev => [newReport, ...prev])
//   //   } catch (err: any) {
//   //     console.error('Failed to generate report:', err)
//   //     setError(`Failed to generate ${type} report. Please try again.`)
      
//   //     const failedReport: Report = {
//   //       id: reportId,
//   //       title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
//   //       description: getReportDescription(type),
//   //       type,
//   //       format,
//   //       generatedAt: new Date().toISOString(),
//   //       period: getReportPeriod(),
//   //       status: 'failed'
//   //     }
      
//   //     setReports(prev => [failedReport, ...prev])
//   //   } finally {
//   //     setGenerating(null)
//   //   }
//   // }

//   const generateReport = async (type: ReportType, format: ReportFormat) => {
//     const reportId = `${type}-${format}-${Date.now()}`
//     setGenerating(reportId)
//     setError(null)
  
//     try {
//       if (format === 'pdf') {
//         // PDF — browser print use karo
//         const response = await apiClient.get('/admin/analytics/export', {
//           params: { format: 'json', type }
//         })
//         const data = response.data
//         const printWindow = window.open('', '_blank')
//         if (printWindow) {
//           printWindow.document.write(`
//             <html>
//               <head>
//                 <title>CivicFix - ${type} Report</title>
//                 <style>
//                   body { font-family: Arial, sans-serif; padding: 20px; }
//                   h1 { color: #4f46e5; }
//                   h2 { color: #374151; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px; }
//                   table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
//                   th { background: #f3f4f6; padding: 8px; text-align: left; border: 1px solid #e5e7eb; }
//                   td { padding: 8px; border: 1px solid #e5e7eb; font-size: 13px; }
//                   .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
//                   .stat { background: #f9fafb; padding: 16px; border-radius: 8px; border: 1px solid #e5e7eb; }
//                   .stat-value { font-size: 24px; font-weight: bold; color: #4f46e5; }
//                   .stat-label { font-size: 12px; color: #6b7280; margin-top: 4px; }
//                 </style>
//               </head>
//               <body>
//                 <h1>CivicFix Analytics Report</h1>
//                 <p>Generated: ${new Date().toLocaleString()}</p>
                
//                 <h2>Summary</h2>
//                 <div class="summary">
//                   <div class="stat"><div class="stat-value">${data.summary?.totalIssues || 0}</div><div class="stat-label">Total Issues</div></div>
//                   <div class="stat"><div class="stat-value">${data.summary?.resolvedIssues || 0}</div><div class="stat-label">Resolved</div></div>
//                   <div class="stat"><div class="stat-value">${data.summary?.totalUsers || 0}</div><div class="stat-label">Total Users</div></div>
//                 </div>
  
//                 <h2>Issues</h2>
//                 <table>
//                   <tr><th>Title</th><th>Category</th><th>Priority</th><th>Status</th><th>Location</th></tr>
//                   ${(data.issues || []).map((i: any) => `
//                     <tr><td>${i.title}</td><td>${i.category}</td><td>${i.priority}</td><td>${i.status}</td><td>${i.location}</td></tr>
//                   `).join('')}
//                 </table>
  
//                 <h2>Users</h2>
//                 <table>
//                   <tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr>
//                   ${(data.users || []).map((u: any) => `
//                     <tr><td>${u.name}</td><td>${u.email}</td><td>${u.role}</td><td>${new Date(u.createdAt).toLocaleDateString()}</td></tr>
//                   `).join('')}
//                 </table>
//               </body>
//             </html>
//           `)
//           printWindow.document.close()
//           printWindow.print()
//         }
//       } else {
//         // CSV / Excel — direct download
//         const actualFormat = format === 'excel' ? 'csv' : format
//         const response = await apiClient.get('/admin/analytics/export', {
//           params: { format: actualFormat, type },
//           responseType: 'blob'
//         })
//         const ext = format === 'excel' ? 'csv' : format
//         const url = window.URL.createObjectURL(new Blob([response.data]))
//         const link = document.createElement('a')
//         link.href = url
//         link.setAttribute('download', `civicfix-${type}-report-${new Date().toISOString().split('T')[0]}.${ext}`)
//         document.body.appendChild(link)
//         link.click()
//         link.remove()
//         window.URL.revokeObjectURL(url)
//       }
  
//       const newReport: Report = {
//         id: reportId,
//         title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
//         description: getReportDescription(type),
//         type,
//         format,
//         generatedAt: new Date().toISOString(),
//         period: getReportPeriod(),
//         status: 'completed',
//       }
//       setReports(prev => [newReport, ...prev])
  
//     } catch (err: any) {
//       console.error('Failed to generate report:', err)
//       setError(`Failed to generate ${type} report. Please try again.`)
//     } finally {
//       setGenerating(null)
//     }
//   }

//   const getReportDescription = (type: ReportType): string => {
//     switch (type) {
//       case 'issues':
//         return 'Comprehensive overview of all issues reported, resolved, and in progress'
//       case 'users':
//         return 'Detailed analysis of user registration, activity patterns, and demographics'
//       case 'performance':
//         return 'Platform performance metrics and volunteer performance statistics'
//       case 'financial':
//         return 'Financial overview and resource allocation analysis'
//       case 'system':
//         return 'System health metrics and platform usage statistics'
//       default:
//         return 'Automatically generated system report'
//     }
//   }

//   const getReportPeriod = (): string => {
//     const now = new Date()
//     const month = now.toLocaleString('default', { month: 'long' })
//     const year = now.getFullYear()
//     return `${month} ${year}`
//   }

//   const handleRetry = () => {
//     fetchReports()
//   }

//   const handleDownload = async (report: Report) => {
//     if (!report.downloadUrl) return

//     try {
//       const link = document.createElement('a')
//       link.href = report.downloadUrl
//       link.download = `${report.title.toLowerCase().replace(/\s+/g, '-')}.${report.format}`
//       document.body.appendChild(link)
//       link.click()
//       document.body.removeChild(link)
//     } catch (err) {
//       console.error('Failed to download report:', err)
//       setError('Failed to download report. Please try again.')
//     }
//   }

//   const handleRegenerate = (report: Report) => {
//     generateReport(report.type, report.format)
//   }

//   const handleDismissError = () => {
//     setError(null)
//   }

//   if (loading && !reports.length) {
//     return null
//   }

//   if (error && !reports.length) {
//     return (
//       <div className="min-h-screen bg-gray-50 py-8">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="flex items-center justify-center h-64">
//             <div className="text-center">
//               <div className="text-red-600 mb-2">⚠️</div>
//               <p className="text-gray-900 font-medium mb-2">Something went wrong</p>
//               <p className="text-gray-600 text-sm mb-4">{error}</p>
//               <button
//                 onClick={handleRetry}
//                 className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
//               >
//                 Try Again
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>
//     )
//   }

//   return (
//       <div className="min-h-screen bg-gray-50 py-8">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <ReportsHeader onRefresh={handleRetry} />

//           {error && (
//             <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
//               <div className="flex items-start justify-between">
//                 <div className="flex-1">
//                   <p className="text-red-800 font-medium">{error}</p>
//                 </div>
//                 <div className="flex space-x-2 ml-4">
//                   <button
//                     onClick={handleRetry}
//                     className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700"
//                   >
//                     Retry
//                   </button>
//                   <button
//                     onClick={handleDismissError}
//                     className="px-3 py-1 bg-gray-200 text-gray-700 text-sm rounded hover:bg-gray-300"
//                   >
//                     Dismiss
//                   </button>
//                 </div>
//               </div>
//             </div>
//           )}

//           <ReportGenerator 
//             generating={generating} 
//             onGenerateReport={generateReport} 
//           />

//           <ReportsList 
//             reports={reports} 
//             onDownload={handleDownload}
//             onRegenerate={handleRegenerate}
//           />
//         </div>
//       </div>
//   )
// }


'use client'

import React, { useState, useEffect } from 'react'
import apiClient from '@/lib/services/api/client'
import ReportsHeader from './components/ReportsHeader'
import ReportGenerator from './components/ReportGenerator'
import ReportsList from './components/ReportsList'

type ReportType = 'issues' | 'users' | 'performance' | 'financial' | 'system'
type ReportFormat = 'pdf' | 'csv' | 'excel'

interface Report {
  id: string
  title: string
  description: string
  type: ReportType
  format: ReportFormat
  generatedAt: string
  period: string
  downloadUrl?: string
  status?: 'generating' | 'completed' | 'failed'
  fileSize?: string
}

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchReports()
  }, [])

  const fetchReports = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await apiClient.get('/admin/reports')
      setReports(response.data.reports || response.data.data || [])
    } catch (err: any) {
      console.error('Failed to fetch reports:', err)
      setError(err.message || 'Failed to load reports. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const generateReport = async (type: ReportType, format: ReportFormat) => {
    const tempId = `${type}-${format}-${Date.now()}`
    setGenerating(tempId)
    setError(null)

    // ✅ Generating state vich temporarily show karo
    const tempReport: Report = {
      id: tempId,
      title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
      description: getReportDescription(type),
      type,
      format,
      generatedAt: new Date().toISOString(),
      period: getReportPeriod(),
      status: 'generating',
    }
    setReports(prev => [tempReport, ...prev])

    try {
      // Analytics export call
      const exportResponse = await apiClient.get('/admin/analytics/export', {
        params: { format }
      })

      const reportPayload = {
        title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
        description: getReportDescription(type),
        type,
        format,
        period: getReportPeriod(),
        status: 'completed',
        downloadUrl: exportResponse.data?.downloadUrl || null,
        fileSize: exportResponse.data?.fileSize || null,
      }

      // ✅ DB vich permanently save karo
      const saveResponse = await apiClient.post('/admin/reports', reportPayload)
      const savedReport: Report = saveResponse.data.data

      // temp report replace karo saved one naal
      setReports(prev =>
        prev.map(r => r.id === tempId ? { ...savedReport, status: 'completed' } : r)
      )

    } catch (err: any) {
      console.error('Failed to generate report:', err)
      setError(`Failed to generate ${type} report. Please try again.`)

      // ✅ Failed report bhi DB vich save karo
      try {
        const failedPayload = {
          title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
          description: getReportDescription(type),
          type,
          format,
          period: getReportPeriod(),
          status: 'failed',
        }
        const saveResponse = await apiClient.post('/admin/reports', failedPayload)
        const savedFailedReport: Report = saveResponse.data.data

        setReports(prev =>
          prev.map(r => r.id === tempId ? { ...savedFailedReport, status: 'failed' } : r)
        )
      } catch {
        // Save fail hove ta temp report failed mark karo
        setReports(prev =>
          prev.map(r => r.id === tempId ? { ...r, status: 'failed' } : r)
        )
      }
    } finally {
      setGenerating(null)
    }
  }

  const getReportDescription = (type: ReportType): string => {
    switch (type) {
      case 'issues': return 'Comprehensive overview of all issues reported, resolved, and in progress'
      case 'users': return 'Detailed analysis of user registration, activity patterns, and demographics'
      case 'performance': return 'Platform performance metrics and volunteer performance statistics'
      case 'financial': return 'Financial overview and resource allocation analysis'
      case 'system': return 'System health metrics and platform usage statistics'
      default: return 'Automatically generated system report'
    }
  }

  const getReportPeriod = (): string => {
    const now = new Date()
    return `${now.toLocaleString('default', { month: 'long' })} ${now.getFullYear()}`
  }

  const handleDownload = async (report: Report) => {
    if (!report.downloadUrl) return
    try {
      const link = document.createElement('a')
      link.href = report.downloadUrl
      link.download = `${report.title.toLowerCase().replace(/\s+/g, '-')}.${report.format}`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (err) {
      console.error('Failed to download report:', err)
      setError('Failed to download report. Please try again.')
    }
  }

  const handleRegenerate = (report: Report) => {
    generateReport(report.type, report.format)
  }

  // ✅ Delete report from DB
  const handleDelete = async (report: Report) => {
    try {
      await apiClient.delete(`/admin/reports?id=${report.id}`)
      setReports(prev => prev.filter(r => r.id !== report.id))
    } catch (err: any) {
      setError('Failed to delete report. Please try again.')
    }
  }

  const handleRetry = () => fetchReports()
  const handleDismissError = () => setError(null)

  if (loading && !reports.length) return null

  if (error && !reports.length) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="text-red-600 mb-2">⚠️</div>
              <p className="text-gray-900 font-medium mb-2">Something went wrong</p>
              <p className="text-gray-600 text-sm mb-4">{error}</p>
              <button
                onClick={handleRetry}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ReportsHeader onRefresh={handleRetry} />

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-start justify-between">
              <p className="text-red-800 font-medium flex-1">{error}</p>
              <div className="flex space-x-2 ml-4">
                <button
                  onClick={handleRetry}
                  className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700"
                >
                  Retry
                </button>
                <button
                  onClick={handleDismissError}
                  className="px-3 py-1 bg-gray-200 text-gray-700 text-sm rounded hover:bg-gray-300"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        )}

        <ReportGenerator
          generating={generating}
          onGenerateReport={generateReport}
        />

        <ReportsList
          reports={reports}
          onDownload={handleDownload}
          onRegenerate={handleRegenerate}
          onDelete={handleDelete}
        />
      </div>
    </div>
  )
}