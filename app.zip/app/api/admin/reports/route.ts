// // app/api/admin/reports/route.ts
// import { NextRequest, NextResponse } from 'next/server';
// import { connectToDatabase } from '@/lib/db';
// import { getCurrentUser } from '@/lib/auth/getCurrentUser';

// export async function GET(req: NextRequest) {
//   try {
//     const currentUser = getCurrentUser(req);
//     if (!currentUser || currentUser.role !== 'admin') {
//       return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
//     }
 
//     const { db } = await connectToDatabase();

//     const now = new Date();
//     const month = now.toLocaleString('default', { month: 'long' });
//     const year = now.getFullYear();
//     const period = `${month} ${year}`;

//     const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

//     // Run all counts in parallel
//     const [
//       totalIssues,
//       resolvedIssues,
//       inProgressIssues,
//       reportedIssues,
//       assignedIssues,
//       totalCitizens,
//       totalVolunteers,
//       issuesThisMonth,
//       resolvedThisMonth,
//       topVolunteers,
//       issuesByCategory,
//       issuesByPriority,
//     ] = await Promise.all([
//       db.collection('issues').countDocuments(),
//       db.collection('issues').countDocuments({ status: 'resolved' }),
//       db.collection('issues').countDocuments({ status: 'in_progress' }),
//       db.collection('issues').countDocuments({ status: 'reported' }),
//       db.collection('issues').countDocuments({ status: 'assigned' }),
//       db.collection('citizens').countDocuments({ role: 'citizen' }),
//       db.collection('citizens').countDocuments({ role: 'volunteer' }),
//       db.collection('issues').countDocuments({ createdAt: { $gte: startOfMonth } }),
//       db.collection('issues').countDocuments({ status: 'resolved', resolvedAt: { $gte: startOfMonth } }),
//       db.collection('citizens').find({ role: 'volunteer', isActive: true })
//         .sort({ 'volunteerStats.tasksCompleted': -1 })
//         .limit(5)
//         .project({ name: 1, 'volunteerStats.tasksCompleted': 1, 'volunteerStats.averageRating': 1 })
//         .toArray(),
//       db.collection('issues').aggregate([
//         { $group: { _id: '$category', count: { $sum: 1 } } },
//         { $sort: { count: -1 } },
//         { $limit: 10 },
//       ]).toArray(),
//       db.collection('issues').aggregate([
//         { $group: { _id: '$priority', count: { $sum: 1 } } },
//         { $sort: { count: -1 } },
//       ]).toArray(),
//     ]);

//     const resolutionRate = totalIssues > 0 ? Math.round((resolvedIssues / totalIssues) * 100) : 0;

//     const reports = [
//       {
//         id: 'issues-summary',
//         title: 'Issues Summary Report',
//         description: 'Comprehensive overview of all issues reported, resolved, and in progress',
//         type: 'issues',
//         format: 'pdf',
//         generatedAt: now.toISOString(),
//         period,
//         status: 'completed',
//         fileSize: null,
//         downloadUrl: null,
//         summary: {
//           total: totalIssues,
//           resolved: resolvedIssues,
//           inProgress: inProgressIssues,
//           reported: reportedIssues,
//           assigned: assignedIssues,
//           resolutionRate,
//           thisMonth: issuesThisMonth,
//           resolvedThisMonth,
//           byCategory: issuesByCategory.map(i => ({ category: i._id, count: i.count })),
//           byPriority: issuesByPriority.map(i => ({ priority: i._id, count: i.count })),
//         },
//       },
//       {
//         id: 'users-summary',
//         title: 'User Activity Report',
//         description: 'Detailed analysis of user registration, activity patterns, and demographics',
//         type: 'users',
//         format: 'csv',
//         generatedAt: now.toISOString(),
//         period,
//         status: 'completed',
//         fileSize: null,
//         downloadUrl: null,
//         summary: {
//           totalCitizens,
//           totalVolunteers,
//           totalUsers: totalCitizens + totalVolunteers,
//         },
//       },
//       {
//         id: 'performance-summary',
//         title: 'Performance Report',
//         description: 'Platform performance metrics and volunteer performance statistics',
//         type: 'performance',
//         format: 'pdf',
//         generatedAt: now.toISOString(),
//         period,
//         status: 'completed',
//         fileSize: null,
//         downloadUrl: null,
//         summary: {
//           resolutionRate,
//           resolvedIssues,
//           totalVolunteers,
//           topVolunteers: topVolunteers.map(v => ({
//             name: v.name,
//             tasksCompleted: v.volunteerStats?.tasksCompleted || 0,
//             rating: v.volunteerStats?.averageRating || 0,
//           })),
//         },
//       },
//       {
//         id: 'system-summary',
//         title: 'System Health Report',
//         description: 'System health metrics and platform usage statistics',
//         type: 'system',
//         format: 'csv',
//         generatedAt: now.toISOString(),
//         period,
//         status: 'completed',
//         fileSize: null,
//         downloadUrl: null,
//         summary: {
//           totalIssues,
//           totalUsers: totalCitizens + totalVolunteers,
//           issuesThisMonth,
//           resolvedThisMonth,
//         },
//       },
//     ];

//     return NextResponse.json({
//       reports,
//       meta: {
//         total: reports.length,
//         generatedAt: now.toISOString(),
//         period,
//       },
//     });
//   } catch (error) {
//     console.error('GET /api/admin/reports error:', error);
//     return NextResponse.json(
//       { message: 'Failed to fetch reports' },
//       { status: 500 }
//     );
//   }
// }


import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth/getCurrentUser'
import { ObjectId } from 'mongodb'

// GET /api/admin/reports — saari saved reports fetch karo
export async function GET(req: NextRequest) {
  try {
    const user = getCurrentUser(req)
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    const { db } = await connectToDatabase()

    const reports = await db
      .collection('generatedReports')
      .find({})
      .sort({ generatedAt: -1 }) // newest first
      .toArray()

    const formatted = reports.map(r => ({
      id: r._id.toString(),
      title: r.title,
      description: r.description,
      type: r.type,
      format: r.format,
      generatedAt: r.generatedAt,
      period: r.period,
      status: r.status,
      fileSize: r.fileSize || null,
      downloadUrl: r.downloadUrl || null,
      generatedBy: r.generatedBy || null,
    }))

    return NextResponse.json({ success: true, reports: formatted })

  } catch (error: any) {
    console.error('Reports GET error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

// POST /api/admin/reports — navi report save karo
export async function POST(req: NextRequest) {
  try {
    const user = getCurrentUser(req)
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { title, description, type, format, period, status, fileSize, downloadUrl } = body

    if (!title || !type || !format) {
      return NextResponse.json(
        { success: false, message: 'Missing required fields: title, type, format' },
        { status: 400 }
      )
    }

    const { db } = await connectToDatabase()

    const reportData = {
      title,
      description: description || '',
      type,
      format,
      period: period || '',
      status: status || 'completed',
      fileSize: fileSize || null,
      downloadUrl: downloadUrl || null,
      generatedAt: new Date().toISOString(),
      generatedBy: user.id,
      createdAt: new Date(),
    }

    const result = await db.collection('generatedReports').insertOne(reportData)

    return NextResponse.json({
      success: true,
      message: 'Report saved successfully',
      data: {
        id: result.insertedId.toString(),
        ...reportData,
      }
    }, { status: 201 })

  } catch (error: any) {
    console.error('Reports POST error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

// DELETE /api/admin/reports?id=xxx — report delete karo
export async function DELETE(req: NextRequest) {
  try {
    const user = getCurrentUser(req)
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')

    if (!id || !ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, message: 'Invalid report ID' }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    await db.collection('generatedReports').deleteOne({ _id: new ObjectId(id) })

    return NextResponse.json({ success: true, message: 'Report deleted' })

  } catch (error: any) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}