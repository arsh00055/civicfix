// // import { NextRequest, NextResponse } from 'next/server'
// // import { connectToDatabase } from '@/lib/db'
// // import { getCurrentUser } from '@/lib/auth/getCurrentUser'

// // // GET /api/admin/settings
// // export async function GET(req: NextRequest) {
// //   try {
// //     const user = getCurrentUser(req)
// //     if (!user || user.role !== 'admin') {
// //       return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
// //     }

// //     const { db } = await connectToDatabase()

// //     const stored = await db.collection('systemSettings').findOne({ key: 'global' })
// //     // No row yet: respond with defaults (client can PATCH to persist).
// //     const settings = stored ?? getDefaultSettings()

// //     return NextResponse.json({ success: true, data: settings })
// //   } catch (error: any) {
// //     return NextResponse.json({ success: false, message: error.message }, { status: 500 })
// //   }
// // }

// // // PATCH /api/admin/settings
// // export async function PATCH(req: NextRequest) {
// //   try {
// //     const user = getCurrentUser(req)
// //     if (!user || user.role !== 'admin') {
// //       return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
// //     }

// //     const body = await req.json()
// //     const { db } = await connectToDatabase()

// //     await db.collection('systemSettings').updateOne(
// //       { key: 'global' },
// //       {
// //         $set: {
// //           ...body,
// //           key: 'global',
// //           updatedAt: new Date(),
// //           updatedBy: user.id,
// //         }
// //       },
// //       { upsert: true }
// //     )

// //     return NextResponse.json({ success: true, message: 'Settings saved successfully' })
// //   } catch (error: any) {
// //     return NextResponse.json({ success: false, message: error.message }, { status: 500 })
// //   }
// // }

// // function getDefaultSettings() {
// //   return {
// //     key: 'global',

// //     // General
// //     siteName: 'CivicFix',
// //     supportEmail: 'support@civicfix.com',
// //     maintenanceMode: false,

// //     // User Registration
// //     allowCitizenRegistration: true,
// //     allowVolunteerRegistration: true,
// //     requireEmailVerification: false,

// //     // Issue Settings
// //     autoAssignIssues: false,
// //     maxImagesPerIssue: 5,
// //     issueExpiryDays: 90,

// //     // Notifications
// //     sendWelcomeEmail: true,
// //     sendIssueUpdateEmails: true,
// //     sendWeeklyDigest: false,

// //     // Volunteer Settings
// //     requireVolunteerApproval: true,
// //     maxTasksPerVolunteer: 5,
// //   }
// // }

// import { NextRequest, NextResponse } from 'next/server'
// import { connectToDatabase } from '@/lib/db'
// import { getCurrentUser } from '@/lib/auth/getCurrentUser'

// // GET /api/admin/settings
// export async function GET(req: NextRequest) {
//   try {
//     const user = getCurrentUser(req)
//     if (!user || user.role !== 'admin') {
//       return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
//     }

//     const { db } = await connectToDatabase()
//     const settings = await db.collection('systemSettings').findOne({ key: 'global' })

//     // Je DB vich nahi ta defaults return karo
//     if (!settings) {
//       return NextResponse.json({ success: true, data: getDefaultSettings() })
//     }

//     // _id hatao response ton
//     const { _id, ...rest } = settings
//     return NextResponse.json({ success: true, data: rest })

//   } catch (error: any) {
//     console.error('Settings GET error:', error)
//     return NextResponse.json({ success: false, message: error.message }, { status: 500 })
//   }
// }

// // PATCH /api/admin/settings
// export async function PATCH(req: NextRequest) {
//   try {
//     const user = getCurrentUser(req)
//     if (!user || user.role !== 'admin') {
//       return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
//     }

//     const body = await req.json()
//     const { db } = await connectToDatabase()

//     await db.collection('systemSettings').updateOne(
//       { key: 'global' },
//       {
//         $set: {
//           ...body,
//           key: 'global',
//           updatedAt: new Date(),
//           updatedBy: user.id,
//         }
//       },
//       { upsert: true }
//     )

//     return NextResponse.json({ success: true, message: 'Settings saved successfully' })

//   } catch (error: any) {
//     console.error('Settings PATCH error:', error)
//     return NextResponse.json({ success: false, message: error.message }, { status: 500 })
//   }
// }

// function getDefaultSettings() {
//   return {
//     key: 'global',
//     // General
//     siteName: 'CivicFix',
//     supportEmail: 'support@civicfix.com',
//     maintenanceMode: false,
//     // User Registration
//     allowCitizenRegistration: true,
//     allowVolunteerRegistration: true,
//     // Issues
//     autoAssignIssues: false,
//     maxImagesPerIssue: 5,
//     issueExpiryDays: 90,
//     // Notifications
//     sendWelcomeEmail: true,
//     sendIssueUpdateEmails: true,
//     sendWeeklyDigest: false,
//     // Volunteers
//     requireVolunteerApproval: true,
//     maxTasksPerVolunteer: 5,
//   }
// }



import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth/getCurrentUser'

// GET /api/admin/settings — public read (registration check lyi)
export async function GET(req: NextRequest) {
  try {
    const { db } = await connectToDatabase()
    const settings = await db.collection('systemSettings').findOne({ key: 'global' })

    if (!settings) {
      return NextResponse.json({ success: true, data: getDefaultSettings() })
    }

    const { _id, ...rest } = settings
    return NextResponse.json({ success: true, data: rest })

  } catch (error: any) {
    console.error('Settings GET error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

// PATCH /api/admin/settings — sirf admin kar sakda
export async function PATCH(req: NextRequest) {
  try {
    const user = getCurrentUser(req)
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { db } = await connectToDatabase()

    await db.collection('systemSettings').updateOne(
      { key: 'global' },
      {
        $set: {
          ...body,
          key: 'global',
          updatedAt: new Date(),
          updatedBy: user.id,
        }
      },
      { upsert: true }
    )

    return NextResponse.json({ success: true, message: 'Settings saved successfully' })

  } catch (error: any) {
    console.error('Settings PATCH error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

function getDefaultSettings() {
  return {
    key: 'global',
    siteName: 'CivicFix',
    supportEmail: 'support@civicfix.com',
    maintenanceMode: false,
    allowCitizenRegistration: true,
    allowVolunteerRegistration: true,
  }
}