import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { ObjectId } from 'mongodb';
import { getCurrentUser } from '@/lib/auth/getCurrentUser';
import { updateUserStatsAndCheckAchievements } from '@/lib/helpers/userStats.helper';
import { notifyReporterIssueVoted } from '@/lib/helpers/notification.helper';


function toObjectId(id: string) {
  try { return new ObjectId(id); } catch { return null; }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = getCurrentUser(req);
    if (!user) return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });

    const { id } = await params;
    const oid = toObjectId(id);
    if (!oid) return NextResponse.json({ message: 'Invalid issue ID' }, { status: 400 });

    const { db } = await connectToDatabase();
    const issue = await db.collection('issues').findOne({ _id: oid });
    if (!issue) return NextResponse.json({ message: 'Issue not found' }, { status: 404 });

    const voters: string[] = issue.voters || [];
    const hasVoted = voters.includes(user.id);

    let update: any;
    if (hasVoted) {
      update = {
        $pull: { voters: user.id },
        $inc: { upvotes: -1 },
        $set: { updatedAt: new Date().toISOString() },
      };
    } else {
      update = {
        $addToSet: { voters: user.id },
        $inc: { upvotes: 1 },
        $set: { updatedAt: new Date().toISOString() },
      };
    }

    await db.collection('issues').updateOne({ _id: oid }, update);

    if (issue.reporterId !== user.id && !hasVoted) {
      const totalVotes = (voters.length || 0);
      await notifyReporterIssueVoted(issue.reporterId, id, issue.title, user.name, totalVotes);
    }

    if (!hasVoted) {
      await updateUserStatsAndCheckAchievements(
        user.id,
        user.role as 'citizen' | 'volunteer',
        { totalVotes: 1, points: 5 }
      );
    }

    const updated = await db.collection('issues').findOne({ _id: oid });
    const { _id, ...rest } = updated!;

    return NextResponse.json({
      ...rest,
      id: _id.toString(),
      voted: !hasVoted,
      upvotes: updated?.upvotes || 0,
      message: hasVoted ? 'Vote removed' : 'Vote recorded',
    });
  } catch (error: any) {
    console.error('POST /api/issues/[id]/vote error:', error);
    return NextResponse.json(
      { message: 'Failed to vote', error: error.message },
      { status: 500 }
    );
  }
}